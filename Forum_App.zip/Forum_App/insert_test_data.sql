--Insert data into the tables
USE myForum;
INSERT INTO Post (name,topic,username,content)VALUES('Does working alongside university stress?','Lifestyle','AaronB','It can be very hard to maintain a work life balance.');
INSERT INTO Users (first_name,last_name,username,password,email)VALUES('Aaron','Bankole','AaronB','AB','aaronbankole12@gmail.com');